package org.cnu.realcoding.riot_crawling.riot_crawling.domain;

import lombok.Data;

@Data
public class Dog {
    private String name;
    private String type;
}
