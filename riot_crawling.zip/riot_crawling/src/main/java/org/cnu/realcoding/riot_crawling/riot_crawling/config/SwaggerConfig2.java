package org.cnu.realcoding.riot_crawling.riot_crawling.config;

public class SwaggerConfig2 {
}
